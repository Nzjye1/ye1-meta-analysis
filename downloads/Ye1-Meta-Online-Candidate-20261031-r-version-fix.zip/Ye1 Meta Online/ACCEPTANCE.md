# 独立 Windows 验收入口

交由获准的新测试会话，在新 Windows x64 用户/目录或明确允许的独立环境执行。若本机或前序会话已有未解除的安装/启动拒绝，先由主会话处理该具体授权，不直接运行这里的后续命令。

参数：`SOURCE` 为解包后的源码根；`RUNTIME` 为全新专用目录（可含空格）；`STUDIES` 为全新合成研究输出目录。必须记录源码 commit、ZIP SHA、Windows 构建号及所有实际命令/退出码。

1. 对 ZIP 完整解包，比对 SOURCE-MANIFEST 中每个文件哈希；运行 `python tools/check_source.py`。检查无运行时、AI 测试 overlay、历史研究目录或个人路径。
2. 先核对安装器布局：CMD 从 `bootstrap/python-<SHA256>` 或 `bootstrap/python-<SHA256>-attempt-N` 目录运行，目标为 `native/python/`，二者必须分离。维护者可用 `setup-online.cmd RUNTIME standard I_ACCEPT prepare-python` 只检验真实引导和 Python 准备；此模式不会安装 R 或写 READY，不能作为完整安装通过。首次/重复/部分 Python 准备及活动目标 EXE 不被重写的回归入口保留在维护源码 tests/real_bootstrap_regression.py。然后在 SOURCE 执行 `setup-online.cmd RUNTIME standard I_ACCEPT`（客户已许可安装并接受条款）。核对首次下载总量 276542214 字节；对照 online-lock 与 download-receipt，确认 R/Python 和包均来自该目录。
3. 按 INSTALL.md 执行 `online_setup.py verify --root RUNTIME --profile standard`、原 launch.cmd 的 check 和新的 synthetic demo；全部成功才记安装烟测通过。保存 setup-logs、READY、last-setup-attempt 与分析结果，失败立即保留，不改策略。
4. 重运行相同 standard 安装，确认哈希缓存复用。可在一次下载中断后重新执行，记录 Range 或整文件重取；篡改测试只用复制出的测试缓存，确认错误文件保留且拒绝安装。
5. 在另一个新目录验收 core；其功能边界明确，不把缺扩展模块当作标准包漏装。按需在 standard 目录追加 docling，核对 226 个固定下载条目、14 个固定模型文件和原许可；运行已有合法公开 PDF/数值词法与冲突 HOLD 回归。
6. 新环境按既有批准配置运行 PLOS 五结局、网络 DL 和 REML 参数隔离及八条路线已有回归。AI 执行的审核如实标 AI，不能转换人工来源。

维护阶段若只运行静态/模拟安装测试，必须列为静态/模拟，不能替换第 2–6 项。首次完整安装、运行时 smoke、实际分析和本轮独立验收在交接时分别报告已跑/未跑。
