# 第三方与官方联网安装

本包中的自有源码、说明和安装工具为 MIT，见 LICENSE。此 ZIP 不含第三方解释器、编译 wheel、R 二进制包或模型，因此不把未核验的本地原生缓存随源码分发。下载后的组件保留各自原许可，不能改写为 MIT，也不能因客户自行安装便忽略我们仍随包提供的材料义务。

`dependencies/online-lock.json` 逐项列出名称、固定版本、官方 URL、字节数、SHA256 和原许可标签。core/standard 的 102 个标准文件在准备阶段由官方 HTTPS 实际取得并固定 SHA；PyPI 的 wheel SHA 同时核对官方元数据。CRAN Windows 索引未给二进制 MD5，R 包核对 ZIP 内 DESCRIPTION 名称/版本后记录维护者 SHA。未声称签名认证或通用法律认证。

| 下载内容 | 保留条款/材料 |
|---|---|
| 官方 CPython 3.14.5 完整 ZIP | PSF 与内含第三方及 Microsoft Windows 二进制附加条件；LICENSE.txt 保留在原生目录 |
| 官方 R 4.6.1 安装器与 76 个 CRAN Windows 包 | R GPL-2/GPL-3 及各包 GPL/LGPL/MIT/BSD 等原条款；原安装器与包中 notices/COPYING/LICENSE 不删除；来源与包版本另记录 |
| 24 个 Python distribution | 原 wheel 的 METADATA、licenses/NOTICE 等保留；含嵌入原生组件的条款仍适用 |
| 可选 Docling 105 个 distribution | 原条款保留；另下载固定 Docling/latex2mathml MIT 原文、LPPL 文本。unimathsymbols 的 LPPL 不被 MIT 覆盖 |
| 可选 Heron / TableFormer | 固定官方 repo commit 和逐文件 SHA；分别 Apache-2.0 / CDLA-Permissive-2.0，模型卡与固定许可文本一并保留 |

下载至客户专用目录是安装，不是允许再分发该目录的声明。Microsoft、R Windows SDK、Intel、OpenCV/FFmpeg 等完整离线分发缺项仍由维护方保留并继续解决；不得把这份在线版打成离线包转发。只有实际接受适用原条款并允许安装后才使用 `I_ACCEPT` / `--accept-third-party-terms`。

官方材料：[CPython Windows 安装](https://docs.python.org/3.14/using/windows.html)、[R 4.6.1 原发行目录](https://cran.r-project.org/bin/windows/base/old/4.6.1/)、[CRAN Windows 包目录](https://cran.r-project.org/bin/windows/contrib/4.6/)、[PyPI](https://pypi.org/)、[Inno 当前用户安装参数](https://jrsoftware.org/ishelp/topic_setupcmdline.htm)。实际下载地址与哈希以固定锁为准，不追踪 latest。
