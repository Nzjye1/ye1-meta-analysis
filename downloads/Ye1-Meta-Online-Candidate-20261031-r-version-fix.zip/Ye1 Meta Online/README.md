# Ye1 Meta：首次联网安装候选

这是 Meta Skill、源码和官方依赖安装流程的本地候选，尚待独立 Windows 验收，不是正式 Release。源码 ZIP 不携带 Python/R、编译库或模型；首次安装直接从锁定的官方来源取得它们。完整离线包另行准备，已有本地环境不能据此视为可交付客户的离线包。

先让 Agent 读取 [Skill 指令](SKILL.md) 和 [安装教程](INSTALL.md)，在独立目录安装并自检，再开始实际研究。所有分析输出使用新的研究目录。原全文 XML/HTML 优先流程与 PDF 路线保留；缺全文请用户提供合法材料。

| 路线 | 教程 |
|---|---|
| 两两 Meta | [协议到报告](app/CUSTOMER-WORKFLOW.md) |
| 稀有事件 MH | [稀有事件](app/RARE-EVENT.md) |
| 相关效应 | [相关效应项目](app/DEPENDENT-PROJECT.md) |
| 频率学网络 | [网络项目](app/NETWORK-PROJECT.md) |
| 单阈值诊断 | [诊断项目](app/DIAGNOSTIC-PROJECT.md) |
| 多阈值诊断 | [多阈值项目](app/MULTITHRESHOLD-PROJECT.md) |
| 剂量反应 | [剂量项目](app/DOSE-PROJECT.md) |
| 单组 | [单组项目](app/SINGLE-PROJECT.md) |
| 全文与 PDF | [全文数值确认](app/FULLTEXT-EXTRACTION.md)、[可选 Docling](app/DOCLING-PDF.md) |

Ye1 拥有授权权利的内容采用 [CC BY-NC 4.0](LICENSE)，第三方保留 [原许可](THIRD-PARTY.md)。历史授权见 [许可说明](LICENSING.md)。[能力边界](CAPABILITIES.md)、[限制与恢复](KNOWN-LIMITATIONS.md)、[隐私边界](PRIVACY.md)。`SOURCE-MANIFEST.json` 对应源码提交和成员指纹；`SOURCE-CHECK.json` 只记录源码检查，不代表安装或科研验收。
