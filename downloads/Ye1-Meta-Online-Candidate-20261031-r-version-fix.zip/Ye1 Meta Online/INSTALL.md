# Windows 首次安装与恢复

目标为 Windows 10/11 x64 客户端，本候选仍需独立验收。ARM64、Mac、Linux 不在本次安装器范围。需要可写的独立目录、首次联网、可执行的 `curl.exe`、`tar.exe`、`certutil.exe` 及原生程序安装权限；安装器会检查缺项并停止，不调整安全策略或请求自动提权。

## 1. Agent 准备

将 ZIP 完整解压，保持 `setup-online.cmd`、`launch.cmd`、`candidate_entry.py`、`tools/`、`app/` 和 `dependencies/` 的相对位置。Agent 先读取本文件、`THIRD-PARTY.md` 及研究路线教程，确认客户允许从官方来源安装、理解适用的原许可，并记录实际选定的运行目录。以下 `C:/Meta Runtime` 是可替换示例，须位于源码和研究数据之外。

| 安装选项 | 内容 | 首次下载字节数 |
|---|---|---:|
| `core` | Python 3.14.5、R 4.6.1、6 个核心 R 包；不含完整扩展与 PDF 依赖 | 137,884,398，约 138 MB |
| `standard`（默认） | 同上，合计 76 个 R 包与 24 个 Python distribution，覆盖全部八类统计路线、文献前端与 pdfplumber | 276,542,214，约 277 MB |
| `docling`（按需） | standard 加 105 个独立 Docling distribution、固定 Heron/TableFormer 模型文件及原许可文本 | 1,150,650,112，约 1.151 GB |

core/standard 数值是维护时实际下载并核验的文件字节数。Docling 合计由官方 wheel Content-Length、已固定模型文件大小与许可文本大小计算，本轮没有重新下载全部可选文件。网络协议、失败重试及未来换版开销另计；固定 URL 若失效或内容变化会停止，不自动升级。安装需要保存下载、解压和恢复副本，建议至少 core/standard 3 GB、Docling 8 GB 可用空间；这是保守空间建议，尚非新安装环境实测峰值。

## 2. 执行一次安装

客户已许可本次安装并接受原许可时，Agent 在源码目录执行：

```powershell
./setup-online.cmd 'C:/Meta Runtime' standard I_ACCEPT
```

此入口无需预装 Python。它通过官方 HTTPS 下载固定 SHA256 的完整 CPython ZIP（不是 embeddable 包），用本机 certutil 核验后解压至专用 `bootstrap/python-<SHA256>/` 引导目录，随后由该引导解释器运行 `tools/online_setup.py`。目标分析解释器另行准备到 `native/python/`；安装器禁止由目标解释器执行安装，已存在且字节相同的目标文件只读复用，不重新写入运行中的 EXE/DLL。该程序核验每个固定下载，运行官方 R 当前用户安装器，将所有包安装到该目录的私有库，检查版本、加载路径、关键 Python 导入与所有选定 R 命名空间，成功后写 `READY.json`。`I_ACCEPT` 是客户实际授权和接受适用原条款的记录参数，不能由 Agent 在用户未同意时伪造。

不更改 PATH、已有 R 的 Current Version 注册、文件关联、执行策略、权限或凭据。官方 R 安装器可能创建当前用户卸载登记；本候选使用 `/CURRENTUSER`、关闭 recordversion/associate/桌面和开始菜单图标，不提供自动管理员回退。若系统拒绝安装或启动，保存错误并停止该动作，交维护者处理；不要更换启动方式来绕过拒绝。

## 3. 核验与实际研究

安装成功后，Agent 读取 `READY.json`、`runtime.json`、`download-receipt.json` 和 `setup-logs/`，再执行独立核验：

```powershell
& 'C:/Meta Runtime/native/python/python.exe' -I -B tools/online_setup.py verify --root 'C:/Meta Runtime' --profile standard
$runtime = 'C:/Meta Runtime'
$env:META_PYTHON = Join-Path $runtime 'native/python/python.exe'
$env:META_RSCRIPT = Join-Path $runtime 'native/R/bin/Rscript.exe'
$env:META_R_LIBRARY = Join-Path $runtime 'libraries/r-extended'
$env:META_METHOD_PYTHON_LIBRARY = Join-Path $runtime 'python/standard'
$env:META_FRONTEND_PYTHON_LIBRARY = $null
./launch.cmd check
./launch.cmd demo --workspace 'C:/Meta Studies/Fresh Synthetic Demo'
```

以上是客户或获准独立验收会话的正常入口，不是在任何已有拒绝后执行的替代方案。若任一步被策略拒绝，应停止并上报。`demo` 完全合成，不能作为真实研究审批。自检后按 [研究流程](app/CUSTOMER-WORKFLOW.md) 或路线教程运行 `./launch.cmd meta ...`，Agent 先取得真实协议/来源判断，再分析合法材料，保存实际命令和输出；不能用示例审批填充客户项目。

## 4. 添加可选 Docling

需要结构化 PDF 候选时才执行：

```powershell
./setup-online.cmd 'C:/Meta Runtime' docling I_ACCEPT
```

同一固定锁下会复用已校验 standard 下载和安装结果，追加独立 Docling 依赖与模型。按 [Docling 教程](app/DOCLING-PDF.md) 为该次进程选择 `python/docling` 与 `python/standard`。解析期间采用固定本地模型和离线 worker，不隐含 OCR。保留 `0,09` 原词法，来源 SD 冲突维持 HOLD，不自动裁决。

## 5. 恢复、失败和卸载

断网后在同一源码、同一目录和同一 profile 下重运行安装命令。首个约 36 MB Python 引导 ZIP 中断时重新下载；后续下载支持 HTTP Range，服务端不支持时从头重取该文件，完成后仍核对全文件 SHA256。已核验文件复用；哈希不符或未知目录不会被覆盖，先保存错误交维护者。不完整引导目录会保留并依次选择新的 `-attempt-N` 引导目录（最多 16 个），已完成的引导目录复用且不再次解压；目标 Python 的部分文件会先全树预检，只补充缺失文件。不同字节或未知文件会停止，已有目标文件不会覆盖。失败的安装 stage 和日志保留，重试建立新 stage；成功扩展 R 库时旧的本安装器库留在 `setup-history/`。已安装文件若改变会阻止复用，不默默修复或升级。

错误时读取 `last-setup-attempt.json`、`current-phase.json` 及 `setup-logs/*-failure.json`；记录中包含实际引导解释器、目标路径、错误类型、errno/winerror 与堆栈。不要把所有 Permission denied 直接解释为策略限制，也不要提权重试。`python-preparation.json` 只证明 Python 准备，不代表完整安装或可运行统计。

`online-owner.json` 绑定依赖锁；不同锁须新目录。`READY.json` 仅在验证成功后更新；失败升级时旧 READY 仍只表示旧 profile，须检查 `last-setup-attempt.json`。真实研究、原目录和历史环境不会被本安装器清理。

不自动卸载。保留研究与证据后，由客户通过官方 R 卸载入口处理该专用安装，再按其确认删除专用运行目录；不要把系统已有 Python/R 或其他项目当作本产品目录删除。缓存和离线环境不得据此打包转发给客户，完整离线包另有分发材料核验流程。
