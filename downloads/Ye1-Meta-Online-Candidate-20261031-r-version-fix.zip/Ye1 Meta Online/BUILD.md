# 维护者构建与独立验收

维护源码仓库的 `packaging/build_clean_source_zip.py` 从干净已提交树生成本候选。执行 `python packaging/build_clean_source_zip.py --out NEW_EMPTY_BUILD --verify-python APPROVED_PYTHON`，输出 ZIP、完整解包树、源码检查和逐成员 SHA256 回执。工具位于维护仓库，不是客户运行前提。

本 ZIP 不携带原生运行时、wheel、R ZIP 或模型，`dependencies/online-lock.json` 固定官方 URL、版本、字节数、SHA256 和原许可标签。锁变化应重新做完整安装/回归，再以新目录安装，不能原地更新客户版本。固定哈希提供内容一致性；维护下载通过 HTTPS，未声称完成 Authenticode/Sigstore 验证。

独立验收见 [验收入口](ACCEPTANCE.md)。本构建检查不启动原生程序，不替代 Windows 安装、真实分析或排版验收；不得重试先前已被拒绝的启动操作或换入口绕过。
